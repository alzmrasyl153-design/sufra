# سفرة — Flutter v1
نسخة أولية من تطبيق طلبات المطاعم.

## التشغيل
1. ثبّت Flutter وAndroid Studio.
2. افتح هذا المجلد كمشروع Flutter.
3. نفّذ:
   flutter pub get
   flutter run

## إنشاء APK
بعد تثبيت Android SDK وتشغيل المشروع:
flutter build apk --release

ملف APK الناتج عادةً يكون داخل:
build/app/outputs/flutter-apk/app-release.apk

هذه النسخة واجهة أولية محلية: السلة تعمل داخل التطبيق، لكن تسجيل الدخول والدفع وقاعدة البيانات والتوصيل لم تُربط بعد.
