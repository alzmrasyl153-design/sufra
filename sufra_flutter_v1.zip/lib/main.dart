import 'package:flutter/material.dart';

void main() => runApp(const SufraApp());

class SufraApp extends StatelessWidget {
  const SufraApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'سفرة',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Arial',
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFF47B00)),
        scaffoldBackgroundColor: const Color(0xFFF7F6F3),
      ),
      home: const HomePage(),
    );
  }
}

class Food {
  final String name, price, emoji;
  const Food(this.name, this.price, this.emoji);
}

const foods = [
  Food('برجر اللحم الكلاسيكي', '1500 ر.س', '🍔'),
  Food('بيتزا مارغريتا', '2000 ر.س', '🍕'),
  Food('وجبة الدجاج الحار', '1400 ر.س', '🍗'),
  Food('ساندويتش سفرة', '1200 ر.س', '🥪'),
];

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  final List<Food> cart = [];

  @override
  Widget build(BuildContext context) {
    final pages = [
      _home(),
      _categories(),
      _cart(),
      _orders(),
      _account(),
    ];
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: SafeArea(child: pages[tab]),
        bottomNavigationBar: NavigationBar(
          selectedIndex: tab,
          onDestinationSelected: (i) => setState(() => tab = i),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
            NavigationDestination(icon: Icon(Icons.grid_view_outlined), label: 'الأقسام'),
            NavigationDestination(icon: Icon(Icons.shopping_cart_outlined), label: 'السلة'),
            NavigationDestination(icon: Icon(Icons.receipt_long_outlined), label: 'طلباتي'),
            NavigationDestination(icon: Icon(Icons.person_outline), label: 'حسابي'),
          ],
        ),
      ),
    );
  }

  Widget _home() => ListView(
    padding: const EdgeInsets.fromLTRB(18, 16, 18, 24),
    children: [
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        const Text('♧', style: TextStyle(fontSize: 26)),
        const Text('سفرة', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900, color: Color(0xFFF47B00))),
        const Icon(Icons.person_outline, size: 27),
      ]),
      const SizedBox(height: 14),
      Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
        child: const Row(children: [Icon(Icons.search, color: Colors.grey), SizedBox(width: 8), Text('ماذا تشتهي اليوم؟', style: TextStyle(color: Colors.grey))]),
      ),
      const SizedBox(height: 18),
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(color: const Color(0xFF171717), borderRadius: BorderRadius.circular(20)),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('عروض اليوم', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
            const Text('خصم على جميع الوجبات', style: TextStyle(color: Colors.white70)),
            const SizedBox(height: 7),
            const Text('20%', style: TextStyle(color: Color(0xFFFF8A00), fontSize: 30, fontWeight: FontWeight.bold)),
            FilledButton(onPressed: () {}, child: const Text('اطلب الآن')),
          ]),
          const Text('🍔', style: TextStyle(fontSize: 62)),
        ]),
      ),
      const SizedBox(height: 22),
      _title('الأقسام'),
      SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(children: [
        _cat('🍔', 'برجر'), _cat('🍕', 'بيتزا'), _cat('🍗', 'دجاج'), _cat('🥤', 'مشروبات'), _cat('🍰', 'حلويات'),
      ])),
      const SizedBox(height: 22),
      _title('الأكثر طلباً'),
      GridView.builder(
        shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
        itemCount: foods.length, gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: .78),
        itemBuilder: (_, i) => _foodCard(foods[i]),
      ),
    ],
  );

  Widget _title(String s) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Text(s, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
      const Text('عرض الكل', style: TextStyle(color: Color(0xFFF47B00), fontSize: 13)),
    ]),
  );

  Widget _cat(String emoji, String name) => Container(
    width: 78, margin: const EdgeInsets.only(left: 10),
    child: Column(children: [
      Container(width: 70, height: 70, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(17)), alignment: Alignment.center, child: Text(emoji, style: const TextStyle(fontSize: 31))),
      const SizedBox(height: 7), Text(name)
    ]),
  );

  Widget _foodCard(Food food) => InkWell(
    borderRadius: BorderRadius.circular(17),
    onTap: () => setState(() => cart.add(food)),
    child: Container(
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(17)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(child: Container(
          width: double.infinity, alignment: Alignment.center,
          decoration: const BoxDecoration(color: Color(0xFFF1EEE8), borderRadius: BorderRadius.vertical(top: Radius.circular(17))),
          child: Text(food.emoji, style: const TextStyle(fontSize: 58)),
        )),
        Padding(padding: const EdgeInsets.fromLTRB(10, 9, 10, 2), child: Text(food.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold))),
        Padding(padding: const EdgeInsets.fromLTRB(10, 0, 10, 10), child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(food.price, style: const TextStyle(color: Color(0xFFF47B00), fontWeight: FontWeight.bold)),
          const Icon(Icons.add_circle, color: Color(0xFFF47B00)),
        ])),
      ]),
    ),
  );

  Widget _categories() => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('الأقسام', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
    const SizedBox(height: 15),
    for (final x in [('🍔','برجر'),('🍕','بيتزا'),('🍗','دجاج'),('🥤','مشروبات'),('🍰','حلويات')])
      Card(child: ListTile(leading: Text(x.$1, style: const TextStyle(fontSize: 30)), title: Text(x.$2), trailing: const Icon(Icons.chevron_left))),
  ]);

  Widget _cart() => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('السلة', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
    const SizedBox(height: 12),
    if (cart.isEmpty) const Padding(padding: EdgeInsets.all(40), child: Center(child: Text('السلة فارغة'))),
    for (final food in cart) Card(child: ListTile(leading: Text(food.emoji, style: const TextStyle(fontSize: 28)), title: Text(food.name), subtitle: Text(food.price))),
    if (cart.isNotEmpty) FilledButton(onPressed: () {}, child: const Text('إتمام الطلب')),
  ]);

  Widget _orders() => const Center(child: Text('لا توجد طلبات حالياً', style: TextStyle(fontSize: 18)));

  Widget _account() => ListView(padding: const EdgeInsets.all(18), children: const [
    Text('حسابي', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
    SizedBox(height: 20),
    Card(child: ListTile(leading: Icon(Icons.person_outline), title: Text('تسجيل الدخول'))),
    Card(child: ListTile(leading: Icon(Icons.location_on_outlined), title: Text('عناويني'))),
    Card(child: ListTile(leading: Icon(Icons.notifications_none), title: Text('الإشعارات'))),
    Card(child: ListTile(leading: Icon(Icons.settings_outlined), title: Text('الإعدادات'))),
  ]);
}
